var express = require('express')
var mysql = require('mysql')
var mqtt = require('mqtt')

var app = express()
var port = 6060

app.use(express.static("public"))
app.set("views engine", "ejs")
app.set("views", "./views")

var server = require("http").Server(app)
var io = require('socket.io')(server)

app.get('/', function(req, res){
    res.render('views2.ejs')
})

app.get('/history', function(req, res){
    res.render('views1.ejs')
})

server.listen(port, function(){
    console.log('Server listening on port ' + port)
})

//----------------------MQTT-------------------------
var client = mqtt.connect("mqtt://localhost:1883",{clientId:"mqttjs01"});   
var topic1 = "led";
var topic2 = "quaNguong"; //LED cảnh báo hoặc còi ...
var message="test message";
var topic_list=["home/sensors/temperature-humidity","home/sensors/humidity"];

console.log("connected flag  " + client.connected);
client.on("connect",function(){ 
    console.log("connected  "+ client.connected);   
    });

client.on("error",function(error){
    console.log("Can't connect" + error);
    process.exit(1)});  

client.subscribe("home/sensors/temperature-humidity");
client.subscribe("home/sensors/humidity");
//----------------------------------------------------

// SQL--------------------------------------
var con = mysql.createConnection({
	host     : 'localhost',
	user     : 'testuser',
	password : '123456',
	database : 'mydb'
});

// var con = mysql.createConnection({
// 	host     : 'us-cdbr-east-06.cleardb.net',
// 	user     : 'b315b8ae360c48',
// 	password : 'd07d4384',
// 	database : 'heroku_46d626e7af30ec0'
// });
//--------------------------------------------

//---------------------------------------------CREATE TABLE-------------------------------------------------
con.connect(function(err) {
	if (err) throw err;
	console.log("mysql connected");
    var sql ="CREATE TABLE IF NOT EXISTS sensors11(ID int(10) not null primary key auto_increment, Time datetime not null, Temperature int(3) not null, Humidity int(3) not null )"
	con.query(sql, function(err){
		if (err) 
			throw err;
        console.log("Table created");
    });
})

var thresh = [] //ngưỡng
var mode = 0 //trạng thái cảnh báo

var humi_graph=[]; 
var temp_graph=[]; 
var date_graph=[];

var m_time
var newTemp
var newHumi

//--------------------------------------------------------------------
var cnt_check = 0;
client.on('message',function(topic, message, packet){
    console.log("message is "+ message)
    console.log("topic is "+ topic)
    
    newTemp = JSON.parse(message).Temperature
    newHumi = JSON.parse(message).Humidity

    if( topic == topic_list[0] && newTemp != null && newHumi != null){

        console.log("ready to save")
        var n = new Date()//.toMysqlFormat();
        var month = n.getMonth() + 1
        var Date_and_Time = n.getFullYear()+"-"+month+"-"+n.getDate() +" "+ n.getHours()+":"+n.getMinutes()+":"+n.getSeconds();

        var sql = "INSERT INTO sensors11 (Time, Temperature, Humidity) VALUES ('" + Date_and_Time.toString() + "', '" + newTemp + "', '" + newHumi + "')"
        con.query(sql, function(err, result){
            if (err) throw err;
            console.log("Table inserted");
            console.log(Date_and_Time +" "+ newTemp +" "+ newHumi)
                // })       
                    // console.log(result)
                    // console.log(tempData)
        });

        var sql1 = "SELECT * FROM sensors11 ORDER BY ID DESC limit 1"
        con.query(sql1, function(err, result, fields){
            if (err) throw err;
            console.log("Data selected");
            result.forEach(function(value) {
                m_time = value.Time.toString().slice(4,24);
                newTemp = value.Temperature
                newHumi = value.Humidity
                console.log(m_time + " " + value.Temperature + " " + value.Humidity);
                // tempFulldata.push({id: value.ID, time: m_time, temp: value.Temperature, humi: value.Humidity})
                io.sockets.emit('server-update-data', {id: value.ID, time: m_time, temp: value.Temperature, humi: value.Humidity})
            })       
            // console.log(result)
            // console.log(tempData)

            if (humi_graph.length < 20) {
                humi_graph.push(newHumi);
            }
            else{
                for(i=0;i<19;i++){
                    humi_graph[i]=humi_graph[i+1];
                }
                humi_graph[19]=newHumi;
            }

            if (temp_graph.length<20) {
                temp_graph.push(newTemp);
            }
            else{
                for(u=0;u<19;u++){
                    temp_graph[u]=temp_graph[u+1];
                }
                temp_graph[19]=newTemp;
            }

            if (date_graph.length<20) {
                date_graph.push( m_time);
            }
            else{
                for(x=0;x<19;x++){
                    date_graph[x]=date_graph[x+1];
                }
                date_graph[19]=m_time;
            }
            
            console.log(temp_graph)

            io.sockets.emit("server-send-humi_graph",humi_graph);
            io.sockets.emit("server-send-temp_graph",temp_graph);
            io.sockets.emit("server-send-date_graph",date_graph);

            //-------------------------------------------------
            // if(((newTemp>=thresh[0])||(newTemp<=thresh[1]))&&(mode==1)){
            //     io.sockets.emit("qua-nguong");
            //     client.publish(topic2, "on");
            //     mode = 0;
            //     io.sockets.emit("canhBao", "off");
            //     }
            // if(((newTemp<thresh[0])&&(newTemp>thresh[1]))&&(mode==0)){
            //     mode = 1;
            //     io.sockets.emit("canhBao", "on");
            //     }

            // if(mode==1){
            //     io.sockets.emit("canhBao", "on");
            // }
            // else{
            //     io.sockets.emit("canhBao", "off");
            // }

            //-------------------------------------------------
            if(((newTemp>=thresh[0])||(newTemp<=thresh[1]))&&(mode==0)){ //mode = 0 --> user acknow
                io.sockets.emit("qua-nguong");
                client.publish(topic2, "on");
                mode = 1;
                io.sockets.emit("canhBao", "on");
            }
    
            if(((newTemp>=thresh[0])||(newTemp<=thresh[1]))&&(mode==1)){} //mode = 0 --> user knew
    
            if(((newTemp<thresh[0])&&(newTemp>thresh[1]))&&(mode==0)){
                io.sockets.emit("canhBao", "off");
                client.publish(topic2, "off");
            }
    
            if(((newTemp<thresh[0])&&(newTemp>thresh[1]))&&(mode==1)){
                io.sockets.emit("canhBao", "off");
                mode = 0
            }
        });
    }
})

//-----------------------------------------
//Socket

// io.sockets.emit("send-full", tempData)
io.on('connection', function(socket){
    console.log(socket.id + " connected")
    socket.on('disconnect', function(){
        console.log(socket.id + " disconnected")
    })

    socket.on('client-send-thresholds', function(data){
        thresh = data
        console.log(thresh)
    })
    io.sockets.emit("thay-nguong",thresh);

    socket.on("ledChange", function(data){
        if(data == "on"){
            console.log('Bật LED1')
            client.publish(topic1, 'on'); //topic1 : led
        }
        else{
            console.log('Tắt LED1')
            client.publish(topic1, 'off');
        }
    })

    socket.on("client-canhBao", function(data){
        if(data == "on"){
            client.publish(topic2, "on"); //topic2 : quaNguong
        }
        else{
            client.publish(topic2, "off");
            mode = 1
        }
    })

    var sql1 = "SELECT * FROM sensors11 ORDER BY ID"
    con.query(sql1, function(err, result, fields){
        if (err) throw err;
        console.log("Full Data selected");
        var tempFulldata = []
        result.forEach(function(value) {
            var m_time = value.Time.toString().slice(4,24);
            tempFulldata.push({id: value.ID, time: m_time, temp: value.Temperature, humi: value.Humidity})
        })
        io.sockets.emit('send-full', tempFulldata)
    })
    //io.sockets.emit('send-full', tempFulldata)
})
